NAGAON UNIVERSITY LIBRARY DASHBOARD

Upload index.html and all five PNG files to the root of your GitHub Pages repository:
- library-front.png
- library-aisle.png
- reading-room.png
- computer-lab.png
- library-attendance.png

GitHub Pages: Repository > Settings > Pages > Deploy from a branch > select main and /(root) > Save.

University logo: In index.html, replace the logo placeholder div with:
<img src="university-logo.png" alt="Nagaon University logo" style="width:78px;height:78px;object-fit:contain">
Upload your logo file under the name university-logo.png into the same root folder.

Statistics are based on the official University library page and should be checked periodically. External resources may require institutional eligibility or login.
